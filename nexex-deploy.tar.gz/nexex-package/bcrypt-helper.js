#!/usr/bin/env node
// Генератор bcrypt-хеша для пароля администратора
// Использование: node bcrypt-helper.js ТвойПароль
import bcrypt from "bcryptjs";
const pass = process.argv[2];
if (!pass) { console.log("Использование: node bcrypt-helper.js ТвойПароль"); process.exit(1); }
const hash = await bcrypt.hash(pass, 12);
console.log("\nАДМИН_ПАРОЛЬ (вставить в .env как ADMIN_PASSWORD=...):\n");
console.log(hash + "\n");
