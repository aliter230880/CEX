#!/bin/bash
# Загрузить переменные из .env и запустить сервер
if [ -f .env ]; then
  export $(grep -v '^#' .env | xargs)
fi
node --enable-source-maps ./dist/index.mjs
